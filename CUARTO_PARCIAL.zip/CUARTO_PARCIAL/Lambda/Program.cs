﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lambda
{
    class Program
    {
        static void Main(string[] args)
        {
            Delegado dlg = new Delegado();
            int Lunes, Martes, Miercoles, Juevez, Viernes, Sabado, Domingo;
           
            
            Console.WriteLine("BIENVENIDO INGRESE LOS DATOS DE LA SEMANA");
            Console.WriteLine("---*-*---------------____---------------*-*---");
            Console.WriteLine("INGRESE LA TEMPERATURA DEL DIA LUNES");
            Lunes = Convert.ToInt32( Console.ReadLine());
            Console.WriteLine("INGRESE LA TEMPERATURA DEL DIA MARTES");
            Martes = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("INGRESE LA TEMPERATURA DEL DIA MIERCOLES");
            Miercoles = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("INGRESE LA TEMPERATURA DEL DIA JUEVEZ");
            Juevez = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("INGRESE LA TEMPERATURA DEL DIA VIERNES");
            Viernes = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("INGRESE LA TEMPERATURA DEL DIA SABADO");
            Sabado = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("INGRESE LA TEMPERATURA DEL DIA DOMINGO");
            Domingo = Convert.ToInt32(Console.ReadLine());


            Console.WriteLine("---*-*---------------____---------------*-*---");
            Console.WriteLine("---*-*---------------____---------------*-*---");
            Console.WriteLine("---*-*---------------____---------------*-*---");

            
            Console.WriteLine("LA MEDIA DE TEMPERATURA ES");
            dlg.MediaTemperatura(Lunes,Martes,Miercoles,Juevez,Viernes,Sabado,Domingo);

            Console.ReadKey();
        }
    }
}
