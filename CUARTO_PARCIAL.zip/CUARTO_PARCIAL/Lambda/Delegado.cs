﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lambda
{
    delegate double Media(int Lunes, int Martes, int Miercoles,int Juevez,int Viernes,int Sabado, int Domingo);
    class Delegado
    {
        
        public void MediaTemperatura(int Lunes, int Martes, int Miercoles, int Juevez, int Viernes, int Sabado, int Domingo)
        {
             double total;
             
             total = (Lunes + Martes + Miercoles + Juevez + Viernes + Sabado + Domingo) / 7;

            if (total > 35 )
            {
                 Console.WriteLine("QUE SEMANA CALUROSA, LA TEMPERAURA FUE DE :" + total);
            }
            else if (total >=15 && total < 35)
            {
               Console.WriteLine("QUE CLIMA TAN DELICIOSO, LA TEMPERAURA FUE DE :" + total);
            }
            else if (total < 15)
            {
                Console.WriteLine("QUE SEMANA TAN FRIA, LA TEMPERAURA FUE DE :"+total);
            }
            
        } 
    }
}
