﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CUARTO_PARCIAL.Models;
using System.Web.Mvc;

namespace CUARTO_PARCIAL.Controllers
{
    public class OperacionController : Controller
    {
        // GET: Operacion
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult IndexSeleccion()
        {
            return View();
        }

        public ActionResult Operacion()
        {
            Datos N = new Datos();
            N.Numero1 = double.Parse(Request.Form["Numero1"].ToString());
            N.Numero2 = double.Parse(Request.Form["Numero2"].ToString());

            if (N.Numero1 > N.Numero2)
            {
                N.R1 = "SUMA";
                N.Resultado1 = N.Numero1 + N.Numero2;
                N.R2 = "RESTA";
                N.Resultado2 = N.Numero1 - N.Numero2;
            }
            else if (N.Numero1 < N.Numero2)
            {
                N.R1 = "MULTIPLICACION";
                N.Resultado1 = N.Numero1 * N.Numero2;
                N.R2 = "DIVISION";
                N.Resultado2 = N.Numero2 / N.Resultado1;
            }

            return View("Operacion", N);

        }

        public ActionResult Seleccion()
        {
            Datos S = new Datos();
            S.Edad = int.Parse(Request.Form["Edad"].ToString());
            S.Altura= double.Parse(Request.Form["Altura"].ToString());
            S.Peso = double.Parse(Request.Form["Peso"].ToString());

            if (S.Edad >= 18 && S.Altura >= 180 && S.Peso<=80)
            {
                S.R = "FELICIDADES CUMPLE LOS REQUISITOS PARA FORMAR PARTE DE LA SELECCION!!!!!!";
            }
            else if(S.Edad < 18 && S.Altura < 180 && S.Peso > 80)
            {
                S.R = "LO SENTIMOS PERO NO PASO LOS REQUISITOS PRUEBE CON OTRO DEPORTE!!";
            }
            else if (S.Edad < 18 && S.Altura >= 180 && S.Peso <= 80)
            {
                S.R = "LO SENTIMOS PERO ES MENOR DE EDAD!!";
            }
            else if (S.Edad >= 18 && S.Altura < 180 && S.Peso <= 80)
            {
                S.R = "LO SENTIMOS PERO NO TIENE LA ESTATURA MINIMA REQUERIDA!!";
            }
            else if (S.Edad >= 18 && S.Altura >= 180 && S.Peso > 80)
            {
                S.R = "HAGA EJERCICIO Y SUERTE PARA LA PROXIMA!!";
            }

            return View("Seleccion", S);
        }

    }
}