﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CUARTO_PARCIAL.Models
{
    public class Datos
    {
        public double Numero1 { get; set; }
        public double Numero2 { get; set; }

        public double Resultado1 { get; set; }
        public double Resultado2 { get; set; }

        public string R1 { get; set; }
        public string R2 { get; set; }
        public int Edad { get; set; }
        public double Altura { get; set; }
        public double Peso { get; set; }
        public string R { get; set; }
    }
}