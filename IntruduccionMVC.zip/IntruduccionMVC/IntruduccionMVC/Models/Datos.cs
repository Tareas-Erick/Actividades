﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IntruduccionMVC.Models
{
    public class Datos
    {
        public double variableA  { get; set; }
        public double variableB   { get; set; }
        public  double Resultado { get; set; }
    }
}