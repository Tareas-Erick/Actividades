﻿using IntruduccionMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IntruduccionMVC.Controllers
{
    public class OperacionesController : Controller
    {
        // GET: Operaciones
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult IndexMulti()
        {
            return View();
        }
        public ActionResult IndexSuma()
        {
            return View();
        }
        public ActionResult IndexDivision()
        {
            return View();
        }
        public ActionResult Suma()
        {
            Datos obModelo = new Datos();
            obModelo.variableA = 3;
            obModelo.variableB = 5;
            obModelo.Resultado = obModelo.variableA + obModelo.variableB;
            ViewData["Resultado"] = obModelo.Resultado;
            return View();
        }
        public ActionResult Sum()
        {
            Datos obj = new Datos();
            obj.variableA = double.Parse(Request.Form["Valor1"].ToString());
            obj.variableB = double.Parse(Request.Form["Valor2"].ToString());
            obj.Resultado = obj.variableA + obj.variableB;

            return View("Sum", obj);
        }
        public ActionResult Resta()
        {
            Datos obj = new Datos();
            obj.variableA = double.Parse(Request.Form["Valor1"].ToString());
            obj.variableB = double.Parse(Request.Form["Valor2"].ToString());
            obj.Resultado = obj.variableA - obj.variableB;
          
            return View("Resta", obj);
        }
        public ActionResult Division()
        {
            Datos V = new Datos();
            V.variableA = double.Parse(Request.Form["Valor1"].ToString());
            V.variableB = double.Parse(Request.Form["Valor2"].ToString());
            V.Resultado = V.variableA / V.variableB;

            return View("Division", V);
        }
        public ActionResult Multiplicacion()
        {
            Datos V = new Datos();
            V.variableA = double.Parse(Request.Form["Valor1"].ToString());
            V.variableB = double.Parse(Request.Form["Valor2"].ToString());
            V.Resultado = V.variableA * V.variableB;

            return View("Multiplicacion", V);
        }
    }
}